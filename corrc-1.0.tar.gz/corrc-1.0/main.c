/* $Copyright: $
 * Copyright (c) 2015 by Dr. Yongsheng Bai, Steve Baker
 * All Rights reserved
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "corrc.h"

int sampleSize = 0;
static char _buf[BUFSIZE], _keybuf[BUFSIZE];
static HASH _miRNAsyms, _mRNAsyms, _xsyms;
int debug=1;
uint8_t **_targets;
char **headers = NULL;

/*
 * corrc <miRNA data> <mRNA data> <Target_profiler text> <target_Scan txt> \
 *       <miRanda txt> <toplist> <predicted #> [<output directory>]
 */

int main(int argc, char **argv)
{
  char *input7, *input6, *input3, *input2, *input1, *outdir = ".";
  LList miRNA7, mRNA6, gene0;
  int i, toplist, predicted;

  if (argc < 8) {
    fprintf(stderr,"Usage: corrc <input7> <input6> <input3> <input2> <input1> <toplist> <predicted #> [<output dir>]\n");
    exit(1);
  }
  if (argc > 8) outdir = argv[8];

  if (access(outdir, W_OK)) {
    mkdir(outdir,0777);
  }
  _miRNAsyms = newsymtab(HASH_SIZE);
  _mRNAsyms = newsymtab(HASH_SIZE);
  _xsyms = newsymtab(HASH_SIZE);

  toplist = atoi(argv[6]);
  predicted = atoi(argv[7]);

  miRNA7 = load7(argv[1]);
  input7 = file(argv[1]);
  mRNA6 = load6(argv[2]);
  input6 = file(argv[2]);
  snprintf(_buf, BUFSIZE-1, "%s/%s.%s.output.txt", outdir, input7, input6);
  gene0 = correlate(_buf, mRNA6, miRNA7);

  snprintf(_buf, BUFSIZE-1, "%s/%s.%s.output.txt.sorted", outdir, input7, input6);
  sortgene0(_buf, gene0);

  // Make _miRNAsyms->ents x _mRNAsyms_ents targets matrix:
  _targets = xmalloc(sizeof(uint8_t *) * _miRNAsyms->ents);
  for(i=0; i < _miRNAsyms->ents; i++) {
    _targets[i] = xmalloc(sizeof(uint8_t) * _mRNAsyms->ents);
    memset(_targets[i], 0, sizeof(uint8_t) * _mRNAsyms->ents);
  }
  if (debug) fprintf(stderr,"Symbol tables entries (pre load3-1): miRNA: %d, mRNA: %d\n", _miRNAsyms->ents, _mRNAsyms->ents);

  load3(input3 = argv[3]);
  load2(input2 = argv[4]);
  load1(input1 = argv[5]);

//   if (debug) fprintf(stderr,"Symbol tables entries: miRNA: %d, mRNA: %d\n", _miRNAsyms->ents, _mRNAsyms->ents);
  snprintf(_buf, BUFSIZE-1, "%s/%s.%s.output.txt.sorted.table.expression.txt", outdir, input7,input6);
  targets(_buf, gene0);
  snprintf(_buf, BUFSIZE-1, "%s/toplist.csv", outdir);
  genspreadsheet(_buf, miRNA7, mRNA6, gene0, toplist, predicted);
  if (debug) fprintf(stderr,"Completed.\n");
  return 0;
}


LList load7(char *file)
{
  FILE *fd;
  LList l = newlist();
  char **w;
  int count, i;

  fd = fopen(file, "r");
  if (fd == NULL) {
    fprintf(stderr,"Unable to open %s for reading [%s].\n", file, strerror(errno));
    return NULL;
  }
  if (debug) fprintf(stderr,"Loading %s\n",file);
  while(fgets(_buf, BUFSIZE-1, fd) != NULL) {
    if (_buf[0] == '#') {
      if (headers != NULL) continue;
      chomp(_buf);
      w = split(_buf, "\t", &count);
      headers = malloc(sizeof(char *) * count+1);
      for(i=0; i < count; i++) headers[i] = strdup(w[i]);
    }
    chomp(_buf);
    w = split(_buf, "\t", &count);
    // hash miRNA table here: Key: miRNA_ID; Value: array of miRNA_ID and normalized count values
    list_append(l, w[0], NULL, NULL, nums(w), count);
  }
  fclose(fd);
  return l;
}

LList load6(char *file)
{
  FILE *fd;
  LList l = newlist();
  char **w, *s;
  int count;

  fd = fopen(file, "r");
  if (fd == NULL) {
    fprintf(stderr,"Unable to open %s for reading [%s].\n", file, strerror(errno));
    return NULL;
  }
  if (debug) fprintf(stderr,"Loading %s\n",file);
  while(fgets(_buf, BUFSIZE-1, fd) != NULL) {
    if (_buf[0] == '#') continue;
    chomp(_buf);
    w = split(_buf, "\t", &count);
    /* Specifically for TCGA dataset, remove '|.*' from key: */
    strncpy(_keybuf,w[0],BUFSIZE);
    s = memchr(_keybuf, '|',BUFSIZE);
    if (s) *s = 0;
    list_append(l, _keybuf, NULL, NULL, nums(w), count);
  }
  fclose(fd);
  return l;
}


LList correlate(char *file, LList mRNA6, LList miRNA7)
{
  FILE *fd;
  LList gene0;
  char *a[4];
  struct llent *mRNA6ent, *miRNA7ent;
  double corr, n[2];
  int cv, sv, xv, iv[3];

  fd = fopen(file, "w");
  if (fd == NULL) {
    fprintf(stderr,"Unable to open %s for writing [%s].\n", file, strerror(errno));
    return NULL;
  }
  if (debug) fprintf(stderr,"Correlating...\n");
  a[3] = NULL;
  iv[3] = -1;
  gene0 = newlist();
  for (mRNA6ent = mRNA6->head; mRNA6ent; mRNA6ent = mRNA6ent->nxt) {
    for (miRNA7ent = miRNA7->head; miRNA7ent; miRNA7ent = miRNA7ent->nxt) {
      if (mRNA6ent->length != miRNA7ent->length) {
	fprintf(stderr,"Entity lengths do not match! (mRNA6) %d != %d (miRNA7)\n", mRNA6ent->length, miRNA7ent->length);
	exit(1);
      }
      corr = correlation(mRNA6ent, miRNA7ent);
      snprintf(_buf, BUFSIZE, "%s\t%s\t%.15f", mRNA6ent->key, miRNA7ent->key, corr);
      fprintf(fd, "%s\n", _buf);
      a[0] = symbol(miRNA7ent->key, _miRNAsyms, &cv);
      a[1] = symbol(mRNA6ent->key, _mRNAsyms, &sv);
      a[2] = symbol(miRNA7ent->key, _xsyms, &xv);
      iv[0] = cv;
      iv[1] = sv;
      n[0] = corr;
      list_append(gene0, NULL, a, iv, n, 1);
    }
  }
  fclose(fd);
  return gene0;
}

int genecmp(const void *la, const void *lb)
{
  double a = (*(struct llent **)la)->nv[0];
  double b = (*(struct llent **)lb)->nv[0];
  
  if (a < b) return -1;
  if (a > b) return 1;
  return 0;
}

void sortgene0(char *file, LList gene0)
{
  FILE *fd;
  struct llent **list, *e;
  int i;

  fd = fopen(file, "w");
  if (fd == NULL) {
    fprintf(stderr,"Unable to open %s for writing [%s].\n", file, strerror(errno));
    return;
  }
  if (debug) fprintf(stderr,"Sorting gene0\n");
  list = xmalloc(sizeof(struct llent *) * gene0->length);
  for(i=0, e=gene0->head; e; e=e->nxt) {
    list[i++] = e;
  }
  qsort(&list[0], gene0->length, sizeof(struct llent *), genecmp);

  gene0->head = list[0];
  for(i=0; i < gene0->length-1; i++) {
    fprintf(fd,"%s\t%s\t%.15f\n", list[i]->sv[1], list[i]->sv[2], list[i]->nv[0]);
    list[i]->nxt = list[i+1];
  }
  fprintf(fd,"%s\t%s\t%.15f\n", list[i]->sv[1], list[i]->sv[2], list[i]->nv[0]);
  list[i]->nxt = NULL;
  gene0->tail = list[i];

  free(list);
  fclose(fd);
}

void load3(char *file)
{
  FILE *fd;
  char **w;
  int count, cv, sv;

  fd = fopen(file, "r");
  if (fd == NULL) {
    fprintf(stderr,"Unable to open %s for reading [%s].\n", file, strerror(errno));
    return;
  }
  if (debug) fprintf(stderr,"Loading %s\n",file);
  while(fgets(_buf, BUFSIZE-1, fd) != NULL) {
    if (_buf[0] == '#') continue;
    chomp(_buf);
    w = split(_buf, "\t", &count);
    cv = find_symbol(w[2], _miRNAsyms);
    sv = find_symbol(w[1], _mRNAsyms);
    if (cv >=0 && sv >= 0) _targets[cv][sv] |= PROFILER;
  }
  fclose(fd);
}

void load2(char *file)
{
  FILE *fd;
  char **w;
  int count, line, cv, sv;

  fd = fopen(file, "r");
  if (fd == NULL) {
    fprintf(stderr,"Unable to open %s for reading [%s].\n", file, strerror(errno));
    return;
  }
  if (debug) fprintf(stderr,"Loading %s\n",file);
  line = 0;
  while(fgets(_buf, BUFSIZE-1, fd) != NULL) {
    if (debug > 1 && (line++ % 1000 == 0)) fprintf(stderr,"%6d\r", line);
    if (_buf[0] == '#') continue;
    chomp(_buf);
    w = split(_buf, "\t", &count);
    cv = find_symbol(w[0], _miRNAsyms);
    sv = find_symbol(w[1], _mRNAsyms);
    if (cv >=0 && sv >= 0) _targets[cv][sv] |= SCAN;
  }
  fclose(fd);
}

void load1(char *file)
{
  FILE *fd;
  char **w;
  int count, cv, sv;

  fd = fopen(file, "r");
  if (fd == NULL) {
    fprintf(stderr,"Unable to open %s for reading [%s].\n", file, strerror(errno));
    return;
  }
  if (debug) fprintf(stderr,"Loading %s\n",file);
  while(fgets(_buf, BUFSIZE-1, fd) != NULL) {
    if (_buf[0] == '#') continue;
    chomp(_buf);
    w = split(_buf, "\t", &count);
    if (count <= 12) continue;
    cv = find_symbol(w[1], _miRNAsyms);
    sv = find_symbol(w[12], _mRNAsyms);
    if (cv >=0 && sv >= 0) _targets[cv][sv] |= MIRANDA;
  }
  fclose(fd);
}

void targets(char *file, LList gene0)
{
  FILE *fd;
  struct llent *ent0;
  int cnt = 1;

  fd = fopen(file, "w");
  if (fd == NULL) {
    fprintf(stderr,"Unable to open %s for writing [%s].\n", file, strerror(errno));
    exit(0);
  }
  if (debug) fprintf(stderr,"Targeting...");
  for (ent0 = gene0->head; ent0; ent0 = ent0->nxt) {
    if (debug > 1) fprintf(stderr,"%8d/%8d\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b", cnt++, gene0->length);

    fprintf(fd,"%s\t%s\t%.15f\ttargetprofiler-%s\ttargetscan-%s\tmiRanda-%s\n",
	    ent0->sv[1], ent0->sv[2], ent0->nv[0],
	   (_targets[ent0->iv[0]][ent0->iv[1]] & PROFILER? "Yes" : "NO"),
	   (_targets[ent0->iv[0]][ent0->iv[1]] & SCAN?     "Yes" : "NO"),
	   (_targets[ent0->iv[0]][ent0->iv[1]] & MIRANDA?  "Yes" : "NO"));
  }
  fclose(fd);
  if (debug) fprintf(stderr,"\n");
}

void genspreadsheet(char *file, LList miRNA7, LList mRNA6, LList gene0, int toplist, int predicted)
{
  FILE *fd;
  char *miRNA7key, *mRNA6key, numbuf[30];
  struct llent *g, *miRNA, *mRNA;
  int i, p;

  fd = fopen(file, "w");
  if (fd == NULL) {
    fprintf(stderr,"Unable to open %s for writing [%s].\n", file, strerror(errno));
    exit(0);
  }
  g = miRNA7->head;
  fprintf(fd, "\"Samples\",");
  for(i=1; i < g->length; i++) {
    snprintf(numbuf,29, "%d", i);
    fprintf(fd,"\"%s\"%c", (headers? headers[i] : numbuf), (i < g->length-1? ',' : '\n'));
  }
  for(g = gene0->head; g && toplist; g = g->nxt, toplist--) {
    p = (_targets[g->iv[0]][g->iv[1]] & PROFILER? 1 : 0) +
	(_targets[g->iv[0]][g->iv[1]] & SCAN?     1 : 0) +
	(_targets[g->iv[0]][g->iv[1]] & MIRANDA?  1 : 0);
    if (p >= predicted) {
      miRNA7key = g->sv[0];
      mRNA6key = g->sv[1];
      miRNA = ll_find(miRNA7, miRNA7key);
      mRNA = ll_find(mRNA6, mRNA6key);

      fprintf(fd,"\"%s\",", miRNA->key);
      for(i=1; i < miRNA->length; i++) {
	fprintf(fd,"%.15f%c", miRNA->nv[i], i < miRNA->length-1? ',' : '\n');
      }
      fprintf(fd,"\"%s\",", mRNA->key);
      for(i=1; i < mRNA->length; i++) {
	fprintf(fd,"%.15f%c", mRNA->nv[i], i < mRNA->length-1? ',' : '\n');
      }
    }
  }
  fclose(fd);
}
