/* $Copyright: $
 * Copyright (c) 2015 by Dr. Yongsheng Bai, Steve Baker
 * All Rights reserved
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "corrc.h"

HASH newsymtab(int size)
{
  HASH h;
  int i;
  
  h = xmalloc(sizeof(struct hash));
  h->size = size;
  h->ents = 0;
  h->he = xmalloc(sizeof(struct hashent **) * size);
  for(i=0;i<size;i++)
    h->he[i] = NULL;
  return h;
}

int hashf(char *key, int size)
{
  int v=tolower(key[0]) % size, i, l = strlen(key);

  for(i=1; i < l; i++) {
    v *= tolower(key[i]);
    v %= size;
  }
  return v;
}

char *symbol(char *val, HASH h, int *ent)
{
  int hpos = hashf(val, h->size), i;
  struct hashent *e, *p, *n;

  for(p=e=h->he[hpos]; e; e=e->nxt) {
    i = strcasecmp(val, e->val);
    if (i == 0) {
      *ent = e->symv;
      return e->val;
    }
    if (i < 0) break;
    p = e;
  }
  
  n = xmalloc(sizeof(struct hashent));
  n->val = strdup(val);
  n->symv = h->ents++;
  n->nxt = e;
  if (p == e) h->he[hpos] = n;
  else p->nxt = n;

  *ent = n->symv;
  return n->val;
}

int find_symbol(char *val, HASH h)
{
  int hpos = hashf(val, h->size), i;
  struct hashent *e;

  for(e=h->he[hpos]; e; e=e->nxt) {
    i = strcasecmp(val, e->val);
    if (i == 0) {
      return e->symv;
    }
    if (i < 0) break;
  }
  return -1;
}
