/* $Copyright: $
 * Copyright (c) 2015 by Dr. Yongsheng Bai, Steve Baker
 * All Rights reserved
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "corrc.h"

void *xmalloc(size_t size)
{
  void *m = malloc(size);
  if (m == NULL) {
    fprintf(stderr,"Out of memory!\n");
    exit(1);
  }
  return m;
}

static char _splitbuf[BUFSIZE];

char **split(char *s, char *delim, int *count)
{
  static char *w[1024];
  int idx = 0;
  
  strncpy(_splitbuf, s, BUFSIZE);
  w[idx++] = strtok(_splitbuf,delim);
  while ((w[idx] = strtok(NULL,delim))) idx++;
  *count = idx;
  return w;
}

static char _ssplitbuf[BUFSIZE];

char **ssplit(char *s, char *delim, int *count)
{
  static char *w[1024];
  int idx = 0;
  
  strncpy(_ssplitbuf, s, BUFSIZE);
  w[idx++] = strtok(_ssplitbuf,delim);
  while ((w[idx] = strtok(NULL,delim))) idx++;
  *count = idx;
  return w;
}

static char _idbuf[BUFSIZE];

char *cleanID(char *s)
{
  int count;
  char **ap, *a, *n;
  
  ap = ssplit(s, "-", &count);
  if (count > 2) {
    for(a = n = ap[2]; *n; n++) {
      if (isalpha(*n) || *n == '*') continue;
      *a++ = *n;
    }
    *a=0;
  } else {
    ap[2] = "";
    if (count < 2) ap[1] = "";
  }
  snprintf(_idbuf, BUFSIZE, "%s-%s-%s", ap[0], ap[1], ap[2]);
  return _idbuf;
}

char *chomp(char *s)
{
  int l;
  l = strlen(s)-1;
  while (l >= 0 && (s[l] == '\n' || s[l] == '\r')) l--;
  s[l+1] = 0;
  return s;
}

double *nums(char **w)
{
  static double n[1024];
  int i;
  
  for(i=0;w[i];i++) {
    n[i] = strtod(w[i], NULL);
  }
  n[i] = 0.0;
  return n;
}

char *file(char *s)
{
  char *p = strrchr(s, '/');
  if (p != NULL) return p+1;
  return s;
}
