/* $Copyright: $
 * Copyright (c) 2015 by Dr. Yongsheng Bai, Steve Baker
 * All Rights reserved
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "corrc.h"

LList newlist()
{
  LList l = xmalloc(sizeof(struct llhead));
  
  l->head = l->tail = NULL;
  l->length = 0;
  return l;
}

void list_append(LList l, char *key, char **svalue, int *ivalue, double *value, int count)
{
  int i;
  struct llent *n;

  n = xmalloc(sizeof(struct llent));
  n->key = key? strdup(key) : NULL;
  n->length = count;
  n->nxt = NULL;

  if (svalue) {
    for(i=0;svalue[i];i++);
    n->sv = xmalloc(sizeof(char *) * i);
    for(i=0; svalue[i]; i++)
      n->sv[i] = svalue[i];
  } else n->sv = NULL;

  if (ivalue) {
    for(i=0;ivalue[i] >= 0;i++);
    n->iv = xmalloc(sizeof(int) * i);
    for(i=0; ivalue[i] >= 0;i++) {
      n->iv[i] = ivalue[i];
    }
  } else n->iv = NULL;

  if (value) {
    n->nv = xmalloc(sizeof(double) * count);
    for(i=0; i < count;i++) {
      n->nv[i] = value[i];
    }
  } else n->nv = NULL;

  l->length++;
  if (l->tail) {
    l->tail->nxt = n;
    l->tail = n;
  } else l->head = l->tail = n;
}

struct llent *ll_find(LList list, char *key)
{
  struct llent *p;
  
  for(p=list->head; p; p=p->nxt) {
    if (strcmp(p->key, key) == 0) return p;
  }
  return NULL;
}
