#!/usr/bin/python
# $Copyright: $
# Copyright (c) 2015 by Dr. Yongsheng Bai, Steve Baker
# All Rights reserved
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import sys
import csv
import xlsxwriter

if len(sys.argv) < 2:
  sys.stderr.write("Usage: xls.py <input.csv> [<output.xlsx>]\n")
  sys.exit(1)

if len(sys.argv) < 3:
  xlsfile = 'Plot_chart.xlsx'
else:
  xlsfile = sys.argv[2]

with open(sys.argv[1], 'rb') as csvfile:
  data = csv.reader(csvfile, delimiter=',', quotechar='"')
  workbook = xlsxwriter.Workbook(xlsfile)
  sheetcnt=0
  headers = data.next()
  for i in xrange(1,len(headers)):
    if headers[i] == "":
      headers[i] = str(i)
  #miRNA = data.next()
  #mRNA = data.next()
  for miRNA in data:
    sheetcnt=sheetcnt+1
    sheet="Sheet"+str(sheetcnt)
    mRNA = data.next();
    worksheet = workbook.add_worksheet()
    chart = workbook.add_chart({ 'type': "line" });
    worksheet.write_string(0,0,"Samples");
    i=0
    for f in miRNA:
      if i>0:
	worksheet.write_number(i, 1, float(f))
	worksheet.write_string(i, 0, headers[i])
      else:
        worksheet.write_string(i, 1, f);
      i=i+1
    i=i-1
    chart.add_series({
      'categories': [ sheet, 1, 0, i, 0 ],
      'values'    : [ sheet, 1, 1, i, 1 ],
      'name'      : [ sheet, 0, 1 ]
    })
    i=0
    for f in mRNA:
      if i>0:
	worksheet.write_number(i, 2, float(f));
      else:
        worksheet.write_string(i, 2, f);
      i=i+1
    i=i-1
    chart.add_series({
      'categories': [ sheet, 1, 0, i, 0 ],
      'values'    : [ sheet, 1, 2, i, 2 ],
      'y2_axis'   : 1,
      'name'      : [ sheet, 0, 2 ]
    })
    worksheet.insert_chart(1, 4, chart, {'x_offset': 1, 'y_offset': 1, 'x_scale': 2.5, 'y_scale': 3})
  workbook.close();
