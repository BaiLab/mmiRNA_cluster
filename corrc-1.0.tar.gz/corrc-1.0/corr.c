/* $Copyright: $
 * Copyright (c) 2015 by Dr. Yongsheng Bai, Steve Baker
 * All Rights reserved
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "corrc.h"

double correlation(struct llent *one, struct llent *two)
{
  double mean_x, mean_y, ssxx, ssyy, ssxy;

  mean(one, two, &mean_x, &mean_y);
  ssxx = ss(mean_x, mean_y, one, one);
  ssyy = ss(mean_x, mean_y, two, two);
  ssxy = ss(mean_x, mean_y, one, two);
  return correl(ssxx, ssyy, ssxy);
}

void mean(struct llent *one, struct llent *two, double *mu_x, double *mu_y)
{
   double sum_x, sum_y, num;
   int i;

   sum_x = 0.0;
   sum_y = 0.0;
   num = ((double)one->length)-1.0;
   for(i = 1; i < one->length; i++) {
     sum_x += one->nv[i];
     sum_y += two->nv[i];
   }
   *mu_x = sum_x / num;
   *mu_y = sum_y / num;
}


double ss(double mean_x, double mean_y, struct llent *one, struct llent *two)
{
  double sum;
  int i;

  sum = 0.0;
  for(i = 1; i < one->length; i++) {
    sum += (one->nv[i] - mean_x) * (two->nv[i] - mean_y);
  }
  return sum;
}

double correl(double ssxx, double ssyy, double ssxy)
{
  double sign, correl;

  correl = 1000000;
  if (ssxy != 0) {
    sign = ssxy / fabs(ssxy);
    // Faster, more correct?
    //sign = signbit(ssxy)? -1 : 1;
    correl = sign * sqrt(ssxy*ssxy/(ssxx*ssyy));
  }
  return correl;
}
