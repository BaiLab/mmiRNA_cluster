/* $Copyright: $
 * Copyright (c) 2015 by Dr. Yongsheng Bai, Steve Baker
 * All Rights reserved
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <stdint.h>
#include <errno.h>
#include <ctype.h>
#include <math.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <xlsxwriter.h>

#define BUFSIZE		8192
#define HASH_SIZE	65536

enum targets { PROFILER = 1, SCAN = 2, MIRANDA = 4 };

enum bool {TRUE=1, FALSE=0};

struct llhead {
  int length;
  struct llent *head, *tail;
};

struct llent {
  char *key;
  int length, *iv;
  char **sv;
  double *nv;
  struct llent *nxt;
};

typedef struct llhead *LList;

struct hash {
  int size, ents;
  struct hashent **he;
};

typedef struct hash *HASH;

struct hashent {
  char *val;
  int symv;
  struct hashent *nxt;
};

// cc.c
LList load7(char *file);
LList load6(char *file);
void load3(char *file);
void load2(char *file);
void load1(char *file);
LList correlate(char *file, LList mRNA6, LList miRNA7);
int genecmp(const void *la, const void *lb);
void sortgene0(char *file, LList gene0);
void targets(char *file, LList gene0);
void genspreadsheet(char *file, LList miRNA7, LList mRNA6, LList gene0, int toplist, int predicted);

// list.c
LList newlist();
void list_append(LList l, char *key, char **svalue, int *ivalue, double *value, int count);
struct llent *ll_find(LList list, char *key);

// corr.c
double correlation(struct llent *one, struct llent *two);
void mean(struct llent *one, struct llent *two, double *mu_x, double *mu_y);
double ss(double mean_x, double mean_y, struct llent *one, struct llent *two);
double correl(double ssxx, double ssyy, double ssxy);

// util.c
void *xmalloc(size_t size);
char **split(char *s, char *delim, int *count);
char *cleanID(char *s);
char *chomp(char *s);
double *nums(char **w);
char *file(char *s);

// sym.c
HASH newsymtab(int size);
char *symbol(char *val, HASH h, int *ent);
int find_symbol(char *val, HASH h);

/*
hsa-miR-628.txt:
hsa-miR-628     5.877139667     4.335094333     2.394415        10.626217       12.372765       12.977605       12.18928        9.617293        4.558121        7.586034        16.104881       2.626044

All_mRNA_noHeader_noQuestion_noSLC35E2.txt:
A1BG|1  0.257670135     0.671892443     0.31706634      1.226271481     0.246703953     2.9678667       1.552432325     0.444813521     0.244611284     0.283418663     0.213673059     0.429931701
A1CF|29974      0.294507958     0.005825948     0       0       0       0       0       0       0       0       0       0

Targetprofiler_full.txt:
7mer-m8	CCL22	hsa-miR-181b	4.3	16 55955342	55955374	CUCCAGCCUGCCCACUUCCCUUCAUGAAUGUUX&XAACAUUCAUUGCUGUCGGUGGGU      .........(((((((..(....(((((((((.&.)))))))))....)..)))))))      -20.60  1       4       1       8.3
8mer	NUDT21	hsa-miR-182	4.3	16 55021149	55021181	AGUUUGCAAUUUUGUAUGUUUCAUUGCCAAAX&XUUUGGCAAUGGUAGAACUCACACU      ............(((..((((((((((((((.&.))))))))))...))))..)))..      -20.50  -1      0       1       4.3
no type	PLLP	hsa-miR-187	4.3	16 55847921	55847953	CCGCCGUAGUAUAAGCCUAACAAGCAACACGUX&XUCGUGUCUUGUGUUGCAGCCGG       ((((.((((((((((...........(((((..&..))))))))))))))).).)))       -15.10  -1      3       1       7.3
7mer-m8	ADCY7	hsa-miR-199b-3p	4.3	16 48907607	48907639	UUUAACCACUGACAUGUAAGGAGGACUACUGUX&XACAGUAGUCUGCACAUUGGUUA       ..((((((.....((((.....((((((((((.&.))))))))))..))))))))))       -21.10  1       3       1       7.3

targetscan_60_output_Redo.txt.preprocess.out.txt:
hsa-miR-125b-2-3p       A2M
hsa-miR-1264    A2M
hsa-miR-146ac   A2M
hsa-miR-1620    A2M

v5.txt.homo_sapiens.hsa.miRanda.txt:
Similarity      hsa-miR-647     miRanda miRNA_target    2       120824263       120824281       +       .       16.3205 3.701400e-06    ENST00000295228 INHBB
Similarity      hsa-miR-130a    miRanda miRNA_target    2       120825363       120825385       +       .       16.5359 1.687830e-02    ENST00000295228 INHBB
Similarity      hsa-miR-423-3p  miRanda miRNA_target    2       120825191       120825213       +       .       14.9339 3.308780e-03    ENST00000295228 INHBB
Similarity      hsa-miR-423-5p  miRanda miRNA_target    2       120824821       120824843       +       .       16.5613 3.308780e-03    ENST00000295228 INHBB

*/