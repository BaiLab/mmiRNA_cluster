# /* $Copyright: $
#   * Copyright (c) 2019 by Dr. Yongsheng Bai, Xinqing Dai
# * All Rights reserved
# *
#   * This program is free software; you can redistribute it and/or modify
# * it under the terms of the GNU General Public License as published by
# * the Free Software Foundation; either version 2 of the License, or
# * (at your option) any later version.
# *
#   * This program is distributed in the hope that it will be useful,
# * but WITHOUT ANY WARRANTY; without even the implied warranty of
# * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# * GNU General Public License for more details.
# *
#   * You should have received a copy of the GNU General Public License
# * along with this program; if not, write to the Free Software
# * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
# */
  

# this code calculates 100000 random maximum scores for each louvain shuffled cancer 

# For each cancer, we want to test which clusters are significant. More specifically, 
# we want to find a critical value to compare with each cluster score. In this program, 
# it shuffles a cancer 100000 times, after each shuffle, a shuffled cancer is run by Louvain algorithm and get scores for each cluster, 
# only the largest score is kept. As a result, each cancer has a score pool of 100000 scores correspondingly. 

# A shuffled cancer is generated from an original cancer where all the nodes (mRNA/miRNA) 
# are randomly selected and assigned an edge (T_CC/N_CC pair). 
# The idea of this algorithm is similar to the classic probability question "picking N cards from a box with replacement". 
# However, the difference is that the shuffle algorithm must ensures that all nodes (mRNA/miRNA) appear at least once. 
# [** Note that mRNA pair with mRNA_FC, and miRNA pair with miRNA_FC. In the following context, 
# I'm using mRNA to represent mRNA-mRNA_FC pair, miRNA to represent miRNA-miRNA_FC pair **]
# Suppose in a cancer file, uniquely there are M mRNA, N miRNA, and Q edges.
# Frist, randomly rearrange the order of M mRNA as well as N miRNA so that all nodes appear at least once. 
# Next, pick Q+N mRNA and Q+M miRNA with replacement and integrate to the bottom of each column. Remove duplicate pairs,
# then select the top Q rows, assign each row with an edge value.

# SEE DETAILS IN <explanation document>


require(svMisc) # for progress

wd <- getwd()
# load self defined functions, IMPORTANT
source(paste0(wd, "/func.r"))
wd_cancer <- paste0(wd, "/cancer/")

# read all csv files of cancers
files <- list.files(path=wd_cancer, pattern="*.csv")
files_path <- paste0(wd_cancer, files)
cancer_list = lapply(files_path, read.csv)

# set running times
run <- 1e5

for(x in 1:length(files)){
  print(files[x])
  cancer_name <- substr(files[x], 1, 4)
  cancer <- cancer_list[[x]]
  cancer <- cancer[, c("mRNA", "microRNA", "T_CC", "N_CC", "mRNA_FC", "miRNA_FC")]
  
  #	One of log(miRNA_FC) and log(mRNA_FC) must be positive and the other negative.
  cancer <- cancer[which(cancer$miRNA_FC!=0 & cancer$mRNA_FC!=0),]
  cancer <- cancer[which(log(cancer$miRNA_FC)*log(cancer$mRNA_FC)<0),]
  
  # create a score pool to store random maximum scores
  score_pool <- c()
  system.time({
    for(i in 1:run){
      progress(i/run*100)
      
      t <- shuffle(cancer) %>% louv() 
      score_pool[i] <- lapply(t, myscore) %>% unlist() %>% na.omit() %>% max()
      
    }
  })
  score_pool <- as.data.frame(score_pool)
  output <- paste0(wd, "/cluster_score/", cancer_name, "_score_pool.csv")
  write.csv(score_pool, output, row.names = FALSE)
}
  