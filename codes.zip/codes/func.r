# /* $Copyright: $
#   * Copyright (c) 2019 by Dr. Yongsheng Bai, Xinqing Dai
# * All Rights reserved
# *
#   * This program is free software; you can redistribute it and/or modify
# * it under the terms of the GNU General Public License as published by
# * the Free Software Foundation; either version 2 of the License, or
# * (at your option) any later version.
# *
#   * This program is distributed in the hope that it will be useful,
# * but WITHOUT ANY WARRANTY; without even the implied warranty of
# * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# * GNU General Public License for more details.
# *
#   * You should have received a copy of the GNU General Public License
# * along with this program; if not, write to the Free Software
# * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
# */


library(igraph) # for g.data.frame()
library(data.table) 
library(dplyr) # for %>%


# all major functions are stored here.

#lapply(louv(cancer), nrow) %>% unlist()

# this function is modifed from louvian to meet our data format, 
# it reads a cancer edgelist
# returns sub-edgelist for each louvian cluster
louv <- function(el){
  # a weight value may be applied for louvain alg
  el$weight <- abs(el$T_CC)+abs(el$N_CC)
  temp_el <- el[, c("mRNA", "microRNA", "weight")]
  g = graph.data.frame(temp_el, directed = F)
  # note: cluster_louvain() only returns the node name
  louvain_list <- cluster_louvain(g)
  
  cluster_list <- list()
  for(i in 1:length(louvain_list)){
    curr_cluster_node <- louvain_list[i] %>% unlist()
    # extract miroRNA and mRNA name
    micro_name <- curr_cluster_node[which(curr_cluster_node %like% "hsa")]
    mrna_name <- curr_cluster_node[-which(curr_cluster_node %like% "hsa")]
    # extract sub_edgelist with target microRNA and mRNA
    cluster_list[[i]] <- el[which((el$microRNA %in% micro_name) & (el$mRNA %in% mrna_name)),]
    
  }
  return(cluster_list)
}
# data.table is a litte bit slower (about 0.01 s) than data.frame, tested system.time
#louv1 <- function(el){
#  dt <- as.data.table(el)
#  temp_dt <- dt[, .(mRNA, microRNA)]
#  g <- graph.data.frame(temp_dt, directed = F)
#  louvain_list <- cluster_louvain(g)
#  
#  cluster_list <- list()
#  for(i in 1:length(louvain_list)){
#    curr_cluster_node <- louvain_list[i] %>% unlist()
#    # extract miroRNA and mRNA name
#    micro_name <- curr_cluster_node[which(curr_cluster_node %like% "hsa")]
#    mrna_name <- setdiff(curr_cluster_node, micro_name)
#    # extract sub_edgelist with target microRNA and mRNA
#    cluster_list[[i]] <- dt[(mRNA %in% mrna_name) & (microRNA %in% micro_name)]
#  }
#  return(cluster_list)
#}
  
  
# new_range takes a number and convert it in the range of [0, 1]
# this normalization step is essential for cluster score calculation
new_range <- function(x){
  y <- abs(x)/sqrt(1+x^2)
  return (y)
}

# this function calculates the score of cluster
myscore <- function(el){
  m_FC <- unique(el$mRNA_FC)
  mi_FC <- unique(el$miRNA_FC)
  T_CC <- abs(el$T_CC)
  N_CC <- abs(el$N_CC)
  
  # normalize
  m_FC <- log(m_FC) %>% new_range()
  mi_FC <- log(mi_FC) %>% new_range()
  
  score <- sum(m_FC) + sum(mi_FC) + sum(T_CC) + sum(N_CC)
  return(score)
}


# this function reads an edgelist 
# it returns all the node name as vector
cluster_node <- function(el){
  return(unique(c(as.vector(el$mRNA), as.vector(el$microRNA))))
}

# this function reads an edgelist
# randomly pick an mRNA and an miRNA, check if this pair has been picked before, then assign an edge (T_CC, N_CC)
# it returns the shuffled edgelist
#shuffle1 <- function(el){
#  dt <- as.data.table(el)
#  mrna_pool <- dt[ ,.(mRNA, mRNA_FC)] %>% unique()
#  micro_pool <- dt[ ,.(microRNA, miRNA_FC)] %>% unique()
#  edge_pool <- dt[ ,.(T_CC, N_CC)]
#  
#  n <- nrow(el)
#  
#  curr_mrna <- sample_n(mrna_pool, 10*n, replace = TRUE) 
#  curr_micro <- sample_n(micro_pool, 10*n, replace = TRUE) 
#  picked_pool <- data.table(curr_mrna, curr_micro) %>% unique()
#  
#  picked_pool <- head(picked_pool, n)
#  shuffle_el <- data.table(picked_pool, edge_pool)
#  
#  return(shuffle_el)
#}

# shuffle guarantee all node appear at least once
shuffle <- function(el){
  dt <- as.data.table(el)
  mrna_pool <- dt[ ,.(mRNA, mRNA_FC)] %>% unique()
  micro_pool <- dt[ ,.(microRNA, miRNA_FC)] %>% unique()
  edge_pool <- dt[ ,.(T_CC, N_CC)]
  
  n <- nrow(el)
  
  edge_pool <- edge_pool[sample(.N, n)]
  mset1 <- mrna_pool[sample(.N, nrow(mrna_pool))]
  mset2 <- mrna_pool[sample(.N, n+nrow(micro_pool), replace=T)]
  microset1 <- micro_pool[sample(.N, nrow(micro_pool))]
  microset2 <- micro_pool[sample(.N, n+nrow(mrna_pool), replace=T)]
  
  picked_pool <- cbind(rbind(mset1, mset2), rbind(microset1, microset2)) %>% unique()
  picked_pool <- head(picked_pool, n)
  shuffle_el <- data.table(picked_pool, edge_pool)
  
  return(shuffle_el)
}
