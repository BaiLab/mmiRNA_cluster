# /* $Copyright: $
#   * Copyright (c) 2019 by Dr. Yongsheng Bai, Xinqing Dai
# * All Rights reserved
# *
#   * This program is free software; you can redistribute it and/or modify
# * it under the terms of the GNU General Public License as published by
# * the Free Software Foundation; either version 2 of the License, or
# * (at your option) any later version.
# *
#   * This program is distributed in the hope that it will be useful,
# * but WITHOUT ANY WARRANTY; without even the implied warranty of
# * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# * GNU General Public License for more details.
# *
#   * You should have received a copy of the GNU General Public License
# * along with this program; if not, write to the Free Software
# * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
# */

require(plotly)

wd <- "C:/Users/daixi/OneDrive/Desktop/BioData"

data <- read.csv(paste0(wd, "/result_p3/result.csv"))

data$cancer <- substr(data$cluster, 1, 4)
data1 <- subset(data, cancer %in% c("BLCA", "COAD", "ESCA", "HNSC", "KICH"))
data2 <- subset(data, cancer %in% c("KIRC", "KIRP", "LIHC", "LUAD", "LUSC"))
data3 <- subset(data, cancer %in% c("BRCA", "PRAD", "STAD", "THCA", "UCEC"))


foo <- function(df){
  p <- plot_ly() %>% 
    add_trace(x=log(df$neighbor), y=df$similarity_pct, z=df$common_pair_pct, 
               color=df$cancer,
               marker=list(size=5, sizemode="diameter"),
               text = ~df$cluster,
               type = "scatter3d") %>%
    #add_markers() %>%
    layout(scene = list(xaxis = list(title="ln(neighbor)"),
                        yaxis = list(title="similarity pct"),
                        zaxis = list(title="common pair pct"),
                        annotations = list(list(
                          x = 1.098612,
                          y = 1,
                          z = 0.5,
                          showarrow = T,
                          arrowsize = 0.5,
                          ax = 0,
                          ay = -50,
                          text = "LIHC57",
                          opacity = 0.7
                        ),
                        list(
                          x = 0,
                          y = 0,
                          z = 1,
                          showarrow = T,
                          arrowsize = 0.5,
                          ax = 0,
                          ay = -50,
                          text = "UCEC70",
                          opacity = 0.7
                        ),
                        list(
                          x = 0,
                          y = 0.5,
                          z = 1,
                          showarrow = T,
                          arrowsize = 0.5,
                          ax = 0,
                          ay = -50,
                          text = "THCA42",
                          opacity = 0.7
                        ),
                        list(
                          x = 0,
                          y = 0,
                          z = 0.666667,
                          showarrow = T,
                          arrowsize = 0.5,
                          ax = -50,
                          ay = -30,
                          text = "PRAD42",
                          opacity = 0.7
                        ),
                        list(
                          x = 0.6931472,
                          y = 0,
                          z = 1,
                          showarrow = T,
                          arrowsize = 0.5,
                          ax = -50,
                          ay = -50,
                          text = "THCA43",
                          opacity = 0.7
                        ),
                        list(
                          x = 0,
                          y = 1,
                          z = 1,
                          showarrow = T,
                          arrowsize = 0.5,
                          ax = 50,
                          ay = 0,
                          text = "UCEC65",
                          opacity = 0.7
                        ),
                        list(
                          x = 0.6931472,
                          y = 1,
                          z = 1,
                          showarrow = T,
                          arrowsize = 0.5,
                          ax = 50,
                          ay = 0,
                          text = "UCEC16",
                          opacity = 0.7
                        ),
                        list(
                          x = 5.02388,
                          y = 0.03186,
                          z = 0.00051,
                          showarrow = T,
                          arrowsize = 0.5,
                          ax = -50,
                          ay = -40,
                          text = "LUAD12",
                          opacity = 0.7
                        ))
                      )
    )
  return(p)
}

p <- foo(data)
p

#chart_link = api_create(p, filename=paste0(wd, "scatter3d.t"))
#chart_link
