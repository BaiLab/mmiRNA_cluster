# /* $Copyright: $
#   * Copyright (c) 2019 by Dr. Yongsheng Bai, Xinqing Dai
# * All Rights reserved
# *
#   * This program is free software; you can redistribute it and/or modify
# * it under the terms of the GNU General Public License as published by
# * the Free Software Foundation; either version 2 of the License, or
# * (at your option) any later version.
# *
#   * This program is distributed in the hope that it will be useful,
# * but WITHOUT ANY WARRANTY; without even the implied warranty of
# * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# * GNU General Public License for more details.
# *
#   * You should have received a copy of the GNU General Public License
# * along with this program; if not, write to the Free Software
# * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
# */


library(dplyr) # for %>%
library(ggplot2) # for graph
library(reshape2) # for melt()
library(ggrepel)

#
# main function starts here
#

wd <- "C:/Users/daixi/OneDrive/Desktop/BioData/ali"
wd_score <- paste0(wd, "/cluster_score/")

# read all csv files of cancers
files <- list.files(path=wd_score, pattern="*.csv")
files_path <- paste0(wd_score, files)
score_list = lapply(files_path, read.csv)

for(i in 1:length(score_list)){
  if(i == 1){
    ori_data <- data.frame(score_list[[1]])
    next
  }
  
  ori_data <- cbind(ori_data, data.frame(score_list[[i]]))
}

# change column names, which will be used in legend
cancer_name <- c()
for(i in 1:length(score_list)){
  cancer_name[i] <- substr(files[i], 1, 4)
}
colnames(ori_data) <- cancer_name

all_data <- melt(ori_data)
colnames(all_data) <- c("cancer", "score")
ggplot(all_data, aes(x=score, fill=cancer)) + geom_density(alpha=0.1)

log_data <- all_data
log_data[,2] <- log(log_data[,2])
colnames(log_data) <- c("cancer", "ln_score")
ggplot(log_data, aes(x=log_score, fill=cancer)) +
  geom_density(alpha=0.1,  show.legend=FALSE) +
  xlab("ln(score)") + ylab("density") + 
  theme(axis.title.x = element_text(size=15), 
        axis.title.y = element_text(size=15),
        axis.text.x = element_text(size=13),
        axis.text.y = element_text(size=13)) +
  theme_grey(base_size = 20) 

