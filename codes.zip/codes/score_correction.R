# /* $Copyright: $
#   * Copyright (c) 2019 by Dr. Yongsheng Bai, Xinqing Dai
# * All Rights reserved
# *
#   * This program is free software; you can redistribute it and/or modify
# * it under the terms of the GNU General Public License as published by
# * the Free Software Foundation; either version 2 of the License, or
# * (at your option) any later version.
# *
#   * This program is distributed in the hope that it will be useful,
# * but WITHOUT ANY WARRANTY; without even the implied warranty of
# * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# * GNU General Public License for more details.
# *
#   * You should have received a copy of the GNU General Public License
# * along with this program; if not, write to the Free Software
# * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
# */


# this program reads files from result_p1
# it compares the original cluster score with N random maximum scores, 
# and count how many times cluster score is bigger than random ones. After that, p_score and q_score is calculated. 
# These values are filled in the form from first step to make it complete.
# p-score is used to indicate the significance of such cluster comparing to N maximum random cluster scores.
# p-score is calculated from equation  p=(n+1)/(N+1)
# where n represents the amount of maximum random cluster scores bigger than the original cluster score.

# The q-score is an adjusted p-score from the Benjamini method of controlling the false discovery rate,
# the expected proportion of false discoveries amongst the rejected hypotheses.

# run it everytime after new random score (random_cluster_score.r) is 



wd <- getwd()
wd_result <- paste0(wd, "/result_p1/")
wd_score <- paste0(wd, "/cluster_score/")

# read files
files <- list.files(path=wd_result, pattern="*.csv")
files_path <- paste0(wd_result, files)
result_list <- lapply(files_path, read.csv)

score_files <- list.files(path=wd_score, pattern="*.csv")
score_path <- paste0(wd_score, score_files)
score_list <- lapply(score_path, read.csv)

compare <- function(var1, var2){
  return(sum(var1 < var2))
}


for(i in 1:length(files)){
  run <- nrow(score_list[[i]])
  curr_cancer_result <- result_list[[i]]
  curr_cancer_rdscore <- score_list[[i]]
  curr_cancer_result[,4] <- apply(curr_cancer_result[, 2, drop=F], 1, compare, var2=curr_cancer_rdscore)
  
  curr_cancer_result$p_value <- (curr_cancer_result$count + 1)/(run + 1)
  curr_cancer_result$q_value <- p.adjust(curr_cancer_result$p_value, method="BH")
  
  write.csv(curr_cancer_result, files_path[i], row.names = F)
  print(paste(files[i], "correction done!"))
}
