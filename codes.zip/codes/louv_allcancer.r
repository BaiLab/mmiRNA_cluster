# /* $Copyright: $
#   * Copyright (c) 2019 by Dr. Yongsheng Bai, Xinqing Dai
# * All Rights reserved
# *
#   * This program is free software; you can redistribute it and/or modify
# * it under the terms of the GNU General Public License as published by
# * the Free Software Foundation; either version 2 of the License, or
# * (at your option) any later version.
# *
#   * This program is distributed in the hope that it will be useful,
# * but WITHOUT ANY WARRANTY; without even the implied warranty of
# * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# * GNU General Public License for more details.
# *
#   * You should have received a copy of the GNU General Public License
# * along with this program; if not, write to the Free Software
# * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
# */

# This code reads cancer csv files and produce clusters for each cancer through Louvain algorithm. 

# The output file includes seven columns "cluster_index", "score", "size", "count", "p_value", "q_value", "node". 
# Only "cluster_index", "score", "size" and "node" is filled by far, the rest of columns will be filled in later steps.
# First of all, select columns of interest from cancer csv file: mRNA, microRNA, T_CC, N_CC, mRNA_FC, miRNA_FC. 
# Then add a thresholding value "th" to mRNA_FC and miRNA_FC, where one of the FC value must be bigger than "th" and the other one smaller than "th".
# The thresholding value is set to be 1.5, it is used to get rid of mRNA-miRNA pairs with small FC difference, 
# this is important because FC value is served as weight value in Louvain algorithm that affects the way of clustering. 
#
# Then we want to score each cluster. The score of a cluster involves four variables: mRNA_FC, miRNA_FC, T_CC, and N_CC. 
# (Note that repeated values must be removed before calculation). 
# First, take absolute value of each variable, then normalize mRNA_FC and miRNA_FC to make sure their values are between 0 to 1. 

# SEE DETAILS IN <explanation document>

require(igraph)
require(data.table)
require(svMisc) # for progress

# load BRCA -> louv all data -> shuffle each cluster -> compare score with original cluster score -> data collection

# change your main directory here
mainDir <- "C:/baiyongsheng"
dir.create(file.path(mainDir), showWarnings = FALSE)
setwd(mainDir)

# cerate sub-dir
subdir_name <- c("result_p1", "result_p2", "result_p2_2", "cluster_score")
for(i in 1:length(subdir_name)){
  dir.create(file.path(mainDir, subdir_name[i]), showWarnings = FALSE)
}

wd <- getwd()

# load self defined functions, IMPORTANT
source(paste0(wd, "/func.r")) 
wd_cancer <- paste0(wd, "/cancer/")

# read all csv files of cancers
files <- list.files(path=wd_cancer, pattern="*.csv")
files_path <- paste0(wd_cancer, files)
cancer_list = lapply(files_path, read.csv)


# read each cancer file from cancer_list. 
for(x in 1:length(files)){
  cancer_name <- substr(files[x], 1, 4)
  print(cancer_name)
  cancer <- cancer_list[[x]]
  cancer <- cancer[, c("mRNA", "microRNA", "T_CC", "N_CC", "mRNA_FC", "miRNA_FC")]
  
  #	add a thresholding value to mRNA_FC/miRNA_FC.
  th <- 1.5
  cancer <- cancer[which((cancer$miRNA_FC>th & cancer$mRNA_FC<th) | (cancer$miRNA_FC<th & cancer$mRNA_FC>th)),]
  
  
  original_cluster_list <- louv(cancer)
  cluster_amount <- length(original_cluster_list)
  
  # build result df that includes the following info
  result <- data.frame(matrix(ncol=7))
  colnames(result) <- c("cluster_index", "score", "size", "count", "p_value", "q_value", "node")
  
  # score each cluster
  for(i in 1:cluster_amount){
    score <- myscore(original_cluster_list[[i]])
    curr_node <- cluster_node(original_cluster_list[[i]])
    size <- length(curr_node)
    # fill values to output dataframe
    result[i, ] <- c(i, score, size, 0, 0, 0, paste(curr_node, collapse=" "))
  }
  
  # save output files
  output <- paste0(wd, "/result_p1/result_", cancer_name, ".csv")
  write.csv(result, output, row.names=F)
  
}

