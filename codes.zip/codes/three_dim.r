# /* $Copyright: $
#   * Copyright (c) 2019 by Dr. Yongsheng Bai, Xinqing Dai
# * All Rights reserved
# *
#   * This program is free software; you can redistribute it and/or modify
# * it under the terms of the GNU General Public License as published by
# * the Free Software Foundation; either version 2 of the License, or
# * (at your option) any later version.
# *
#   * This program is distributed in the hope that it will be useful,
# * but WITHOUT ANY WARRANTY; without even the implied warranty of
# * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# * GNU General Public License for more details.
# *
#   * You should have received a copy of the GNU General Public License
# * along with this program; if not, write to the Free Software
# * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
# */


# for each cluster, this program collects three pieces of information as three dimensions.
# dim1: number of neighbors (how many columns of different clusters in each spreadsheet)
# dim2: similarity (the similarity percentage obtained via compare_mtomi.R)
# dim3: the common pair percentage. It is the number of non-zero value divided by total cells.
# take BLCA9 for instance, there are 4 non-zero values of total 88(4*22) cells.
# 4 columns: HNSC46, LUAD5, LUAD12, STAD21
# 22 rows: 22 mRNA-miRNA pairs.
# So, for BLCA9, dim3 = 4/88 = 0.45455


require(dplyr) # for %>%
require(openxlsx) # for open xlsx

# this function calculate how many nonzero element
foo <- function(x){
  return(length(which(!is.na(x))))
}


#
# main function starts here
#

wd <- getwd()
wd_result <- paste0(wd, "/result_p2_2/")

# read all csv files of cancers
files <- list.files(path=wd_result, pattern="*.xlsx")
files_path <- paste0(wd_result, files)
#result_list = lapply(files_path, read.csv)

result <- data.frame()
#colnames(result) <- c("cluster", "dim1", "dim2", "dim3")

for(i in 1:length(files_path)){
  cluster_list <- getSheetNames(files_path[i])
  print(files[i])
  for(k in 1:length(cluster_list)){
    curr_cluster_name <- cluster_list[k]
    print(paste(k, "of", length(cluster_list)))
    curr_cluster <- read.xlsx(files_path[i], sheet = cluster_list[k])
    
    useful_part <- curr_cluster[1:(nrow(curr_cluster)-1), 4:(ncol(curr_cluster)-1), drop=F]
    # dim1 is the number of cancer clusters
    # dim2 is the value obtained via compare_mtomi.R, right bottom corner of the spread sheet
    # dim3 is the number non-zero value divided by total cells.
    #    take BLCA9 as example, there are 4 non-zero values of total 88(4*22) cells.
    #    so for BLCA9, dim3 = 4/88 = 0.45455
    dim1 <- ncol(useful_part)
    dim2 <- curr_cluster[nrow(curr_cluster), ncol(curr_cluster)]
    dim3 <- sum(apply(useful_part, 2, foo)) / prod(dim(useful_part))
    temp <- data.frame(curr_cluster_name, dim1, dim2, dim3)
    result <- rbind(result,temp)
  }
}

colnames(result) <- c("cluster", "neighbor", "similarity_pct", "common_pair_pct")

write.csv(result, paste0(wd, "/result_p3/result.csv"), row.names = FALSE)
