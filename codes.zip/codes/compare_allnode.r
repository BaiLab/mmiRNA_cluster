# /* $Copyright: $
#   * Copyright (c) 2019 by Dr. Yongsheng Bai, Xinqing Dai
# * All Rights reserved
# *
#   * This program is free software; you can redistribute it and/or modify
# * it under the terms of the GNU General Public License as published by
# * the Free Software Foundation; either version 2 of the License, or
# * (at your option) any later version.
# *
#   * This program is distributed in the hope that it will be useful,
# * but WITHOUT ANY WARRANTY; without even the implied warranty of
# * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# * GNU General Public License for more details.
# *
#   * You should have received a copy of the GNU General Public License
# * along with this program; if not, write to the Free Software
# * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
# */


library(igraph) # for g.data.frame()
library(data.table) 
library(dplyr) # for %>%
library(plyr) # for sql query
library(openxlsx) # for multiple sheet in one excel

# this function read a cancer cluster df, mRNA and miRNA columns only
# consider each mRNA and miRNA as vertices
# returns the result of shortest distance among all vertices in the form of matrix and df
node_dist <- function(el){
  g <- graph.data.frame(el, directed=F)
  
  node_mx <- shortest.paths(g)
  node_mx[upper.tri(node_mx)] <- 0
  node_el <- melt(node_mx)
  node_el <- node_el[which(node_el$value>0), ]
  
  result <- list()
  result[[1]] <- node_el
  result[[2]] <- node_mx
  return(result)
}

# this function reads shortest distance matrix from source_cluster and compare_cluster
# if there exist same node pair in comapre_cluster, return its distance
# the return value is a dataframe (empty df if no node pair found)
compare_similarity <- function(src_mx, cmp_mx, cmp_cluster_name){
  
  src_nodepool <- rownames(src_mx)
  cmp_nodepool <- rownames(cmp_mx)
  
  flag <- cmp_nodepool %in% src_nodepool
  if(sum(flag)<2) return(NULL)
  
  common_node <- cmp_nodepool[flag]
  
  node_amount <- nrow(src_mx)
  src_mx_cpy <- matrix(0, ncol=node_amount, nrow=node_amount)
  rownames(src_mx_cpy) <- colnames(src_mx_cpy) <- rownames(src_mx)
  
  for(i in 1:(length(common_node)-1)){
    for(j in (i+1):length(common_node)){
      src_mx_cpy[common_node[i], common_node[j]] <- src_mx_cpy[common_node[j], common_node[i]] <- cmp_mx[common_node[j], common_node[i]]
    }
  }
  
  src_mx_cpy[upper.tri(src_mx_cpy)] <- 0
  output <- melt(src_mx_cpy)
  output <- output[which(output$value>0), ]
  
  colnames(output) <- c("Node1", "Node2", cmp_cluster_name)
  return(output)
}

# this function calculate percentage of similarity for each row
# for x>=4, if row[x, ] == row[3, ], count++
# percentage = count/total
pct_similarity <- function(single_row){
  single_row <- single_row[!is.na(single_row)]
  n <- length(single_row)
  if(n == 1) return(0)
  val <- single_row[1]
  count <- 0
  for(i in 1:n){
    if(single_row[i]==val){
      count = count + 1
    }
  }
  return(count/n)
} 

#
# main function starts here
#

wd <- getwd()
source(paste0(wd, "/func.r"))
wd_cancer <- paste0(wd, "/cancer/")

# read all csv files of cancers
files <- list.files(path=wd_cancer, pattern="*.csv")
files_path <- paste0(wd_cancer, files)
cancer_list = lapply(files_path, read.csv)

# p thresholding value
p_th <- 0.5
# FC thresholding value
fc_th <- 1.5


for(src_idx in 1:length(cancer_list)){
  # select source_cancer
  src_cancer_name <- substr(files[src_idx], 1, 4)
  src_cancer <- cancer_list[[src_idx]]
  #	add a thresholding value to mRNA_FC/miRNA_FC.
  src_cancer <- src_cancer[which((src_cancer$miRNA_FC>fc_th & src_cancer$mRNA_FC<fc_th) | (src_cancer$miRNA_FC<fc_th & src_cancer$mRNA_FC>fc_th)),]
  source_cluster_list <- louv(src_cancer)
  source_cluster_amount <- length(source_cluster_list)
  print(paste(files[src_idx], "has", source_cluster_amount, "clusters"))
  
  # create a blank workbook to store the similarity result of current src_cancer 
  OUT <- createWorkbook()
  
  for(i in 1:source_cluster_amount){
    
    sheetlabel <- paste0(src_cancer_name, i)
    print(sheetlabel)
    source_cluster <- source_cluster_list[[i]][, 1:2]
    # get distance from source cluster
    source_el <- node_dist(source_cluster)[[1]]
    colnames(source_el) <- c("Node1", "Node2", sheetlabel)
    source_mx <- node_dist(source_cluster)[[2]]
    # this flag indicates whether a similar cluster is found
    flag <- 0
  
    for(cmp_idx in 1:length(cancer_list)){
      if(src_idx == cmp_idx) next
      # select compare_cancer
      cmp_cancer <- cancer_list[[cmp_idx]]
      cmp_cancer <- cmp_cancer[which((cmp_cancer$miRNA_FC>fc_th & cmp_cancer$mRNA_FC<fc_th) | (cmp_cancer$miRNA_FC<fc_th & cmp_cancer$mRNA_FC>fc_th)),]
      
      compare_cluster_list <- louv(cmp_cancer)
      compare_cluster_amount <- length(compare_cluster_list)

      for(j in 1:compare_cluster_amount){
        # get distance from compare cluster
        compare_cluster <- compare_cluster_list[[j]][, 1:2]
        compare_cluster_name <- paste0(substr(files[cmp_idx], 1, 4), j)
        compare_mx <- node_dist(compare_cluster)[[2]]
        common_node_el <- compare_similarity(source_mx, compare_mx, compare_cluster_name)
        if(is.null(common_node_el)) next
        else{
          flag <- 1
          source_el <- suppressMessages(join(source_el, common_node_el, type="left"))
        }
      }
      
    }
    # if at least a similar cluster is found, add to worksheet
    if(flag){
      # final percentage similarity calculation.
      source_el[, ncol(source_el)+1] <- apply(source_el[, -1:-2], 1, pct_similarity)
      colnames(source_el)[ncol(source_el)] <- "percentage"
      
      p <- sum(source_el[, ncol(source_el)]> p_th)/nrow(source_el)
      # add an extra row for percentage of similiaryity info
      source_el <- add_row(source_el, "Node1"=paste0("percentage of similarity > ", p_th), "percentage"=p)
      
      # add this worksheet to workbook
      addWorksheet(OUT, sheetlabel)
      writeData(OUT, sheet = sheetlabel, x=source_el)
    }
  }
  # an excel file of all clusters from current cancer has been done.
  output_name <- paste0(wd, "/result_p2/", src_cancer_name, "_similarity_result.xlsx")
  saveWorkbook(OUT, output_name)
}




