# /* $Copyright: $
#   * Copyright (c) 2019 by Dr. Yongsheng Bai, Xinqing Dai
# * All Rights reserved
# *
#   * This program is free software; you can redistribute it and/or modify
# * it under the terms of the GNU General Public License as published by
# * the Free Software Foundation; either version 2 of the License, or
# * (at your option) any later version.
# *
#   * This program is distributed in the hope that it will be useful,
# * but WITHOUT ANY WARRANTY; without even the implied warranty of
# * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# * GNU General Public License for more details.
# *
#   * You should have received a copy of the GNU General Public License
# * along with this program; if not, write to the Free Software
# * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
# */


library(dplyr) # for %>%
library(ggplot2) # for graph
library(directlabels) # for graph_label

#
# main function starts here
#

wd <- getwd()
wd_result <- paste0(wd, "/result_p1/")

# read all csv files
files <- list.files(path=wd_result, pattern="*.csv")
files_path <- paste0(wd_result, files)
result_list <- lapply(files_path, read.csv)

all_data <- data.frame()
for(i in 1:length(result_list)){
  cancer_name <- substr(files[i], 8, 11)
  cancer <- result_list[[i]]
  cancer <- cancer[, c("size", "score", "p_value")]
  
  cancer <- cancer[order(cancer$size),] # sort with cancer size
  cancer$idx <- c(1: nrow(cancer))
  cancer$cancer <- cancer_name
  all_data <- rbind(all_data, cancer)
}

all_data$size <- log2(all_data$size)

# if cluster is significant (p<0.05) use solid point 
shape_node = ifelse(all_data$p_value>0.05, 1, 16)
ggplot(all_data, aes(x=idx, y=size, group=cancer), size =100) +  
  geom_point(size=2, stroke=0, shape=shape_node, aes(color=cancer), show.legend=FALSE) +   #stroke to remove point border
  geom_line(aes(col=cancer), show.legend=FALSE) +
  xlab("cluster index") + ylab("log2(cluster size)") + 
  theme(axis.title.x = element_text(size=15), 
        axis.title.y = element_text(size=15),
        axis.text.x = element_text(size=13),
        axis.text.y = element_text(size=13)) + 
  geom_dl(aes(label = cancer), method = list(dl.trans(y=y+0.2), dl.trans(x=x+0.2), "last.points", cex = 1.0))  #add label to line
